/**
 * 聊天列表
 *
 * @author xutao
 */
package cn.udesk.saas.sdk.adapter;

import java.util.ArrayList;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import cn.udesk.saas.sdk.R;
import cn.udesk.saas.sdk.chat.UDIMMessage;
import cn.udesk.saas.sdk.utils.UDLruCache;

public class UDIMChatAdatper extends BaseAdapter {

    private Context mContext;
    private ArrayList<UDIMMessage> list = new ArrayList<UDIMMessage>();

    private UDLruCache<String, Bitmap> lruCache;

    public UDIMChatAdatper(Context context) {
        mContext = context;

        lruCache = new UDLruCache<String, Bitmap>(20);
    }

    @Override
    public int getCount() {
        return list.size();
    }

    /**
     * 添加历史纪录
     * @param messages
     */
    public void addHistoryArray(ArrayList<UDIMMessage> messages) {
        if(messages == null) {
            return;
        }
        for(int i = messages.size() - 1; i >= 0 ; i --) {
            list.add(0, messages.get(i));
            addLocalBitmap(messages.get(i));
        }
        notifyDataSetChanged();
    }

    /**
     * 添加新的聊天记录
     * @param message
     */
    public void addItem(UDIMMessage message) {
        if(message == null) {
            return;
        }
        list.add(message);
        addLocalBitmap(message);
        notifyDataSetChanged();
    }

    @Override
    public UDIMMessage getItem(int position) {
        if(position < 0 || position >= list.size()) {
            return null;
        }
        return list.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }


    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        //优化ListView
        ItemViewCache viewCache;

        if(convertView == null) {
            convertView = LayoutInflater.from(mContext).inflate(R.layout.udesk_layout_im_item, null);
            viewCache = new ItemViewCache();

            viewCache.mTime = (TextView)convertView.findViewById(R.id.udesk_im_item_time);

            viewCache.mMyItem = (LinearLayout)convertView.findViewById(R.id.udesk_im_item_my);
            viewCache.mMyText = (TextView)convertView.findViewById(R.id.udesk_im_my_message);
            viewCache.mMyImage = (ImageView)convertView.findViewById(R.id.udesk_im_my_image);

            viewCache.mCSItem = (LinearLayout)convertView.findViewById(R.id.udesk_im_item_cs);
            viewCache.mCSText = (TextView)convertView.findViewById(R.id.udesk_im_cs_message);
            viewCache.mCSImage = (ImageView)convertView.findViewById(R.id.udesk_im_cs_image);

            convertView.setTag(viewCache);
        } else {
            viewCache = (ItemViewCache)convertView.getTag();
        }

        UDIMMessage message = list.get(position);

        if((message.type & UDIMMessage.TYPE_TIME) == UDIMMessage.TYPE_TIME) {
            viewCache.mMyItem.setVisibility(View.GONE);
            viewCache.mCSItem.setVisibility(View.GONE);

            viewCache.mTime.setVisibility(View.VISIBLE);
            viewCache.mTime.setText(message.text_url);
        } else {

            viewCache.mTime.setVisibility(View.GONE);

            if((message.type & UDIMMessage.TYPE_MINE) == UDIMMessage.TYPE_MINE) {
                viewCache.mMyItem.setVisibility(View.VISIBLE);
                viewCache.mCSItem.setVisibility(View.GONE);
                if((message.type & UDIMMessage.TYPE_TEXT) == UDIMMessage.TYPE_TEXT) {
                    viewCache.mMyText.setText(UDEmojiAdapter.replaceEmoji(mContext, message.text_url));
                    viewCache.mMyText.setVisibility(View.VISIBLE);
                    viewCache.mMyImage.setVisibility(View.GONE);
                } else {
                    viewCache.mMyImage.setImageBitmap(lruCache.get(message.thumbnailPath));
                    viewCache.mMyText.setVisibility(View.GONE);
                    viewCache.mMyImage.setVisibility(View.VISIBLE);
                }
            } else {
                viewCache.mMyItem.setVisibility(View.GONE);
                viewCache.mCSItem.setVisibility(View.VISIBLE);
                if((message.type & UDIMMessage.TYPE_TEXT) == UDIMMessage.TYPE_TEXT) {
                    viewCache.mCSText.setText(UDEmojiAdapter.replaceEmoji(mContext, message.text_url));
                    viewCache.mCSText.setVisibility(View.VISIBLE);
                    viewCache.mCSImage.setVisibility(View.GONE);
                } else {
                    viewCache.mCSImage.setImageBitmap(lruCache.get(message.thumbnailPath));
                    viewCache.mCSText.setVisibility(View.GONE);
                    viewCache.mCSImage.setVisibility(View.VISIBLE);
                }
            }
        }


        return convertView;
    }


    //元素的缓冲类, 用于优化ListView
    private static class ItemViewCache {
        public LinearLayout mMyItem, mCSItem;
        public TextView mMyText, mCSText;
        public ImageView mMyImage, mCSImage;
        public TextView mTime;
    }


    private void addLocalBitmap(UDIMMessage message) {
        if((message.type & UDIMMessage.TYPE_IMAGE) == UDIMMessage.TYPE_IMAGE) {
            if(!TextUtils.isEmpty(message.thumbnailPath)) {
                lruCache.put(message.thumbnailPath, BitmapFactory.decodeFile(message.thumbnailPath));
            }
        }
    }



}

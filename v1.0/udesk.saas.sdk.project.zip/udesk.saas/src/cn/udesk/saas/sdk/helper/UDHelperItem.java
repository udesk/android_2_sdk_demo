/**
 * 帮助条目信息
 * @author xutao
 */
package cn.udesk.saas.sdk.helper;

public class UDHelperItem {

    public int id;
    public String subject;

}

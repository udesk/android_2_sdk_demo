/**
 * 消息历史记录
 *
 * @author xutao
 */
package cn.udesk.saas.sdk.db;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class UDIMDBHelper extends SQLiteOpenHelper {

    private final static String TAG = "UDESK_DBHelper";

    public final static String DATABASE_NAME     = "udesk_im";
    public final static int    DATABASE_VERSION  = 1;

    public final static String TABLE_NAME = "udesk_im_manager";

    /**
     * @since V1
     */
    public final static String COLUMN_ID            = "id";
    public final static String COLUMN_TYPE          = "type";
    public final static String COLUMN_TEXT_URL      = "text_url";
    public final static String COLUMN_THUMBNAIL_PATH   = "thumbnail_path";


    /**
     * 创建数据库表
     */
    public final static String SQL_CREATE_TABLE =
            "CREATE TABLE IF NOT EXISTS " + TABLE_NAME + "(" +
                    COLUMN_ID + " INTEGER PRIMARY KEY, " +
                    COLUMN_TYPE + " INTEGER, " +
                    COLUMN_TEXT_URL + " VARCHAR, " +
                    COLUMN_THUMBNAIL_PATH + " VARCHAR)";


    public UDIMDBHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }


    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL(SQL_CREATE_TABLE);
    }


    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
    }

}

/**
 * IM 所有逻辑
 *
 * @author xutao
 */
package cn.udesk.saas.sdk.activity;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Locale;
import java.util.Vector;

import org.json.JSONObject;

import android.app.Activity;
import android.content.ContentResolver;
import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.Handler;
import android.provider.MediaStore;
import android.text.TextUtils;
import android.util.Log;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.Button;
import android.widget.EditText;
import android.widget.GridView;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;
import cn.udesk.saas.sdk.R;
import cn.udesk.saas.sdk.UDeskSDK;
import cn.udesk.saas.sdk.adapter.UDEmojiAdapter;
import cn.udesk.saas.sdk.adapter.UDIMChatAdatper;
import cn.udesk.saas.sdk.chat.UDDownloadTask;
import cn.udesk.saas.sdk.chat.UDIMMessage;
import cn.udesk.saas.sdk.chat.UDXmppThread;
import cn.udesk.saas.sdk.db.UDIMDBManager;
import cn.udesk.saas.sdk.manager.UDUserManager;
import cn.udesk.saas.sdk.utils.UDEnvConstants;
import cn.udesk.saas.sdk.utils.UDUtils;
import cn.udesk.saas.sdk.view.UDPullGetMoreListView;
import cn.udesk.saas.sdk.view.UDPullGetMoreListView.OnRefreshListener;

import com.qiniu.android.http.ResponseInfo;
import com.qiniu.android.storage.UpCompletionHandler;
import com.qiniu.android.storage.UpProgressHandler;
import com.qiniu.android.storage.UploadManager;
import com.qiniu.android.storage.UploadOptions;

public class UDIMActivity extends Activity implements OnClickListener, OnItemClickListener {

    private final static String TAG = "IMActivity";

    private static final int CAPTURE_IMAGE_ACTIVITY_REQUEST_CODE = 101;
    private static final int SELECT_IMAGE_ACTIVITY_REQUEST_CODE = 102;

    private UDXmppThread xmppThread = null;

    private static Uri photoUri;

    private UDPullGetMoreListView lvConversation;
    private UDIMChatAdatper mChatAdapter;

    private GridView gvEmojis;
    private UDEmojiAdapter mEmojiAdapter;

    private LinearLayout llLoading, llContent, lloptions, llemojis, llUpload, llBottom;
    private EditText  etMessage;
    private ImageView ivOptions, ivEmojis;
    private TextView  tvNaviLeft, tvNaviTitle, tvSend, tvUpload;

    private Button btnPhoto, btnCamera;

    private long lastSessionTime = 0;

    private UDIMMessage currentUploadImageMessage = null;

    private int historyCount = 0, offset = -1;

    private Vector<String> downloadStack = new Vector<String>();
    private UDDownloadTask downloadTask;


    private Handler mHandler = new Handler() {
        @Override
        public void handleMessage(android.os.Message msg) {
            if(UDIMActivity.this.isFinishing() || !Thread.currentThread().isAlive()) {
                return;
            }

            switch (msg.what) {
            case -2:
                String lastCSId = UDUtils.loadConfigString(UDIMActivity.this, UDEnvConstants.PREF_LAST_CS);
                if(TextUtils.isEmpty(lastCSId)) {
                    Toast.makeText(UDIMActivity.this, R.string.udesk_not_find_customer_service, Toast.LENGTH_LONG).show();
                    finish();
                } else {
                    UDUserManager.getInstance().setCustomerServiceId(lastCSId, false);
                    mHandler.sendEmptyMessage(-1);
                }
                break;

            case -1:

                if(UDEnvConstants.isDebugMode) Log.w(TAG, UDUserManager.getInstance().getCustomerServiceId());

                if(!TextUtils.isEmpty(UDUserManager.getInstance().getCustomerServiceId())) {
                    UDUtils.saveConfigString(
                            UDIMActivity.this,
                            UDEnvConstants.PREF_LAST_CS,
                            UDUserManager.getInstance().getCustomerServiceId());
                }

                if(xmppThread == null) {
                    xmppThread = new UDXmppThread(this);
                }
                xmppThread.start();
                break;

            case 0:
                if(UDUserManager.getInstance().isCustomerServiceOnline()) {
                    tvNaviTitle.setText(R.string.udesk_navi_im_title_online);
                } else {
                    tvNaviTitle.setText(R.string.udesk_navi_im_title_offline);
                }

                loadHistoryRecords();

                llContent.setVisibility(View.VISIBLE);
                llLoading.setVisibility(View.GONE);
                break;

            case 1:  // 有新消息
                if(msg.obj instanceof UDIMMessage) {
                    UDIMMessage udMessage = (UDIMMessage)msg.obj;

                    if((udMessage.type & UDIMMessage.TYPE_IMAGE) == UDIMMessage.TYPE_IMAGE) {
                        addDownloadTask(udMessage.text_url);
                    } else {
                        showNewTime();

                        UDIMDBManager.getInstance().addMessage(udMessage);

                        mChatAdapter.addItem((UDIMMessage)msg.obj);
                        lvConversation.smoothScrollToPosition(mChatAdapter.getCount());
                    }
                }
                break;

            case 2:  // 状态更新
                if(msg.obj instanceof String) {
                    boolean isOnline = Boolean.parseBoolean((String)msg.obj);
                    if(isOnline) {
                        tvNaviTitle.setText(R.string.udesk_navi_im_title_online);
                    } else {
                        tvNaviTitle.setText(R.string.udesk_navi_im_title_offline);
                    }
                }

                break;

            case 11:  // 图片下载成功

                if(msg.obj instanceof String) {

                    showNewTime();

                    UDIMMessage udMessage = new UDIMMessage();
                    udMessage.thumbnailPath = (String)msg.obj;
                    udMessage.type = UDIMMessage.TYPE_IMAGE;

                    UDIMDBManager.getInstance().addMessage(udMessage);

                    mChatAdapter.addItem(udMessage);
                    lvConversation.smoothScrollToPosition(mChatAdapter.getCount());

                } else {
                    Toast.makeText(UDIMActivity.this, R.string.udesk_download_image_fail, Toast.LENGTH_SHORT).show();
                }

                startNextDownload();

                break;

            case 12:  // 图片下载失败
                Toast.makeText(UDIMActivity.this, R.string.udesk_download_image_fail, Toast.LENGTH_SHORT).show();

                startNextDownload();
                break;

            default:
                break;
            }
        }
    };


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.udesk_activity_im);

        tvNaviLeft = (TextView) findViewById(R.id.udesk_navi_left);
        if((UDUserManager.getInstance().getSDKMode() & UDeskSDK.MODE_HELPER) == UDeskSDK.MODE_HELPER) {
            tvNaviLeft.setText(R.string.udesk_navi_back);
        } else {
            tvNaviLeft.setText(R.string.udesk_navi_close);
        }
        tvNaviLeft.setOnClickListener(this);

        tvNaviTitle = (TextView)findViewById(R.id.udesk_navi_title);
        tvNaviTitle.setText(R.string.udesk_navi_im_title_offline);

        llLoading = (LinearLayout)findViewById(R.id.udesk_im_loading);

        llContent = (LinearLayout)findViewById(R.id.udesk_im_content);

        mChatAdapter = new UDIMChatAdatper(this);

        lvConversation = (UDPullGetMoreListView)findViewById(R.id.udesk_conversation);
        lvConversation.setTranscriptMode(ListView.TRANSCRIPT_MODE_ALWAYS_SCROLL);
        lvConversation.setAdapter(mChatAdapter);
        lvConversation.setOnRefreshListener(new OnRefreshListener() {
            @Override
            public void onRefresh() {
                loadHistoryRecords();
            }
        });
        lvConversation.setOnItemClickListener(this);

        llBottom = (LinearLayout)findViewById(R.id.udesk_bottom);

        tvSend = (TextView)findViewById(R.id.udesk_bottom_send);
        tvSend.setOnClickListener(this);

        etMessage = (EditText)findViewById(R.id.udesk_bottom_input);

        llUpload = (LinearLayout)findViewById(R.id.udesk_bottom_upload);
        tvUpload = (TextView)findViewById(R.id.udesk_upload_hint);

        ivOptions = (ImageView)findViewById(R.id.udesk_bottom_show_option);
        ivOptions.setOnClickListener(this);

        ivEmojis = (ImageView)findViewById(R.id.udesk_bottom_show_emoji);
        ivEmojis.setOnClickListener(this);

        llemojis = (LinearLayout)findViewById(R.id.udesk_bottom_emojis);

        mEmojiAdapter = new UDEmojiAdapter(this);
        gvEmojis = (GridView)findViewById(R.id.udesk_bottom_emoji_pannel);
        gvEmojis.setAdapter(mEmojiAdapter);
        gvEmojis.setOnItemClickListener(this);

        lloptions = (LinearLayout)findViewById(R.id.udesk_bottom_options);

        btnCamera = (Button)findViewById(R.id.udesk_bottom_option_camera);
        btnCamera.setOnClickListener(this);

        btnPhoto = (Button)findViewById(R.id.udesk_bottom_option_photo);
        btnPhoto.setOnClickListener(this);

        UDIMDBManager.getInstance().init(this);
        historyCount = UDIMDBManager.getInstance().getMessageCount();

        UDUserManager.getInstance().login(this, mHandler);

    }


    @Override
    protected void onDestroy() {
        mHandler.removeCallbacksAndMessages(null);
        super.onDestroy();
    }


    @Override
    public void onClick(View v) {
        if(v.getId() == R.id.udesk_bottom_send) {

            String text = etMessage.getText().toString().trim();
            etMessage.setText("");
            if(TextUtils.isEmpty(text)) {
                Toast.makeText(UDIMActivity.this, R.string.udesk_send_message_empty, Toast.LENGTH_SHORT).show();
                return;
            }
            sendTextMessage(text);

        } else if(v.getId() == R.id.udesk_bottom_show_option) {

            if(TextUtils.isEmpty(UDUserManager.getInstance().getQiniuToken())) {
                Toast.makeText(this, R.string.udesk_upload_image_forbidden, Toast.LENGTH_LONG).show();
                return;
            }

            if(llemojis.getVisibility() == View.VISIBLE) {
                llemojis.setVisibility(View.GONE);
            }

            if(lloptions.getVisibility() == View.VISIBLE) {
                lloptions.setVisibility(View.GONE);
            } else {
                lloptions.setVisibility(View.VISIBLE);
            }

        } else if(v.getId() == R.id.udesk_bottom_show_emoji) {

            if(lloptions.getVisibility() == View.VISIBLE) {
                lloptions.setVisibility(View.GONE);
            }

            if(llemojis.getVisibility() == View.VISIBLE) {
                llemojis.setVisibility(View.GONE);
            } else {
                llemojis.setVisibility(View.VISIBLE);
            }

        } else if(v.getId() == R.id.udesk_navi_left) {

            closeConnection();
            finish();

        } else if(v.getId() == R.id.udesk_bottom_option_camera) {

            takePhoto();
            lloptions.setVisibility(View.GONE);

        } else if(v.getId() == R.id.udesk_bottom_option_photo) {

            selectPhoto();
            lloptions.setVisibility(View.GONE);

        }
    }


    @Override
    public void onItemClick(AdapterView<?> parent, View view, int position, long id) {

        if(UDEnvConstants.isDebugMode) {
            Log.w(TAG, "onItemClick position:" + position + " id:" + id);
        }

        if(parent == lvConversation) {

            UDIMMessage message = mChatAdapter.getItem((int)id);
            if((message.type & UDIMMessage.TYPE_IMAGE) == UDIMMessage.TYPE_IMAGE) {
                if(!TextUtils.isEmpty(message.thumbnailPath)) {
                    String sourceImagePath;
                    if((message.type & UDIMMessage.TYPE_MINE) == UDIMMessage.TYPE_MINE) {
                        sourceImagePath = message.thumbnailPath.replace("_thumbnail", "_upload");
                    } else {
                        sourceImagePath = message.thumbnailPath.replace("_thumbnail", "_download");
                    }

                    if(UDEnvConstants.isDebugMode) {
                        Log.w(TAG, sourceImagePath);
                    }

                    File sourceFile = new File(sourceImagePath);
                    if(sourceFile.exists()) {
                        Intent intent = new Intent();
                        intent.setAction(android.content.Intent.ACTION_VIEW);
                        intent.setDataAndType(Uri.fromFile(sourceFile), "image/*");
                        startActivity(intent);
                    }
                }
            }

        } else if(parent == gvEmojis) {
            String text = etMessage.getText().toString();
            int selection = etMessage.getSelectionStart();
            String emoji = mEmojiAdapter.getItem((int)id);

            if(selection == text.length()) {
                // 尾部添加
                text += emoji;
            } else {
                // 插入
                text = text.substring(0, selection) + emoji + text.substring(selection);
            }

            etMessage.setText(UDEmojiAdapter.replaceEmoji(this, text));
            etMessage.setSelection(selection + emoji.length());
        }

    }


    @Override
    public void onBackPressed() {
        super.onBackPressed();

        closeConnection();
    }


    private void loadHistoryRecords() {
        // 设置为Normal，加载更多之后，当前条目不变
        lvConversation.setTranscriptMode(ListView.TRANSCRIPT_MODE_NORMAL);

        // 已经没有更早的数据了
        if(offset == 0) {
            Toast.makeText(UDIMActivity.this, R.string.udesk_no_more_history, Toast.LENGTH_SHORT).show();
            lvConversation.onRefreshComplete();
            lvConversation.setSelection(0);
        } else {
            // 还有老数据
            if(offset == -1) {
                offset = historyCount - UDIMDBManager.HISTORY_COUNT;
            } else {
                offset = offset - UDIMDBManager.HISTORY_COUNT;
            }
            offset = (offset < 0 ? 0 : offset);
            ArrayList<UDIMMessage> list = UDIMDBManager.getInstance().getMessages(offset);

            mChatAdapter.addHistoryArray(list);
            lvConversation.onRefreshComplete();
            lvConversation.setSelection(list.size());
        }

        // 延迟1秒设为自动滚动到最下
        lvConversation.postDelayed(new Runnable() {
            @Override
            public void run() {
                lvConversation.setTranscriptMode(ListView.TRANSCRIPT_MODE_ALWAYS_SCROLL);
            }
        }, 1000);
    }


    /**
     * 发消息
     * @param text
     */
    private void sendTextMessage(String text) {
        showNewTime();

        UDIMMessage udMessage = new UDIMMessage();
        udMessage.type = UDIMMessage.TYPE_MINE | UDIMMessage.TYPE_TEXT;
        udMessage.text_url = text;

        UDIMDBManager.getInstance().addMessage(udMessage);

        mChatAdapter.addItem(udMessage);
        lvConversation.smoothScrollToPosition(mChatAdapter.getCount());

        if(xmppThread != null) {
            xmppThread.sendMessage(UDIMMessage.TYPE_TEXT, text);
        }
    }

    /**
     * 关闭连接
     */
    private void closeConnection() {
        if(xmppThread != null) {
            xmppThread.cancel();
            xmppThread = null;
        }
    }


    /**
     * 显示时间
     */
    private void showNewTime() {
        // 5分钟
        if(System.currentTimeMillis() - lastSessionTime >= 1000 * 60 * 1) {

            lastSessionTime = System.currentTimeMillis();

            UDIMMessage udMessage = new UDIMMessage();
            udMessage.type = UDIMMessage.TYPE_TIME;
            DateFormat df = new SimpleDateFormat("MM月dd日 EE HH时mm分", Locale.CHINA);
            udMessage.text_url = df.format(new Date(lastSessionTime));

            UDIMDBManager.getInstance().addMessage(udMessage);

            mChatAdapter.addItem(udMessage);
        } else {
            lastSessionTime = System.currentTimeMillis();
        }
    }


    /**
     * 添加图片下载任务
     * @param downloadUrl
     */
    private void addDownloadTask(String downloadUrl) {
        if(!downloadStack.contains(downloadUrl)) {
            downloadStack.add(downloadUrl);
        }

        statDownloadTask(downloadUrl);
    }


    /**
     * 在完成一个下载之后，启动另一个下载
     */
    private void startNextDownload() {
        downloadTask = null;

        if(downloadStack.size() > 0) {
            downloadStack.remove(0);
        }
        if(downloadStack.size() > 0) {
            statDownloadTask(downloadStack.firstElement());
        } else {
            llBottom.setVisibility(View.VISIBLE);
            llUpload.setVisibility(View.GONE);
        }
    }

    /**
     * 启动下载
     * @param downloadUrl
     */
    private void statDownloadTask(String downloadUrl) {
        if(downloadTask == null) {
            llBottom.setVisibility(View.GONE);
            llUpload.setVisibility(View.VISIBLE);
            tvUpload.setText(R.string.udesk_download_image);

            downloadTask = new UDDownloadTask(UDIMActivity.this, downloadUrl, mHandler);
            downloadTask.execute();
        }
    }


    //########################################################################

    /**
     * 选择要上传的照片
     */
    private void selectPhoto() {
        Intent intent=new Intent(Intent.ACTION_GET_CONTENT);// ACTION_OPEN_DOCUMENT
        intent.addCategory(Intent.CATEGORY_OPENABLE);
        intent.setType("image/jpeg");
        startActivityForResult(intent, SELECT_IMAGE_ACTIVITY_REQUEST_CODE);
    }


    /**
     * 拍照
     */
    private void takePhoto() {
        Intent intent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
        photoUri = UDUtils.getOutputMediaFileUri();
        // 此处这句intent的值设置关系到后面的onActivityResult中会进入那个分支，即关系到data是否为null，如果此处指定，则后来的data为null
        intent.putExtra(MediaStore.EXTRA_OUTPUT, photoUri);
        startActivityForResult(intent, CAPTURE_IMAGE_ACTIVITY_REQUEST_CODE);
    }


    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (CAPTURE_IMAGE_ACTIVITY_REQUEST_CODE == requestCode) {
            if (RESULT_OK == resultCode) {
                // Check if the result includes a thumbnail Bitmap
                if (data != null) {
                    // 没有指定特定存储路径的时候
                    // 指定了存储路径的时候（intent.putExtra(MediaStore.EXTRA_OUTPUT, fileUri);）
                    // Image captured and saved to fileUri specified in the Intent
                    if (data.hasExtra("data")) {
                        Bitmap thumbnail = data.getParcelableExtra("data");

                        if(UDEnvConstants.isDebugMode) {
                            Log.e(TAG, "data != null");
                        }
                        if(thumbnail != null) {
                            sendBitmapMessage(thumbnail);
                        }
                    }
                } else {
                    // If there is no thumbnail image data, the image
                    // will have been stored in the target output URI.
                    // Resize the full image to fit in out image view.

                    if(UDEnvConstants.isDebugMode) {
                        Log.e(TAG, "data == null");
                    }

                    sendBitmapMessage(photoUri.getPath());

                }
            } else if (resultCode == RESULT_CANCELED) {
                // User cancelled the image capture
            } else {
                // Image capture failed, advise user
            }
        } else if(SELECT_IMAGE_ACTIVITY_REQUEST_CODE == requestCode) {

            if(resultCode != RESULT_OK || data == null) {
                return;
            }

            Uri mImageCaptureUri = data.getData();

            if(UDEnvConstants.isDebugMode) {
                Log.e(TAG, "uri=" + mImageCaptureUri);
            }

            //返回的Uri不为空时，那么图片信息数据都会在Uri中获得。如果为空，那么我们就进行下面的方式获取
            if (mImageCaptureUri != null) {
                ContentResolver cr = this.getContentResolver();
                try {
                    Bitmap bitmap = BitmapFactory.decodeStream(cr.openInputStream(mImageCaptureUri));
                    sendBitmapMessage(bitmap);
                } catch (FileNotFoundException e) {
                    Log.e("Exception", e.getMessage(),e);
                }
            } else {
                Bundle extras = data.getExtras();
                if (extras != null) {
                    //这里是有些拍照后的图片是直接存放到Bundle中的所以我们可以从这里面获取Bitmap图片
                    Bitmap bitmap = extras.getParcelable("data");
                    if (bitmap != null) {
                        sendBitmapMessage(bitmap);
                    }
                }
            }

        }

    }



    /**
     * 发送一条图片消息
     * @param bitmap
     */
    private void sendBitmapMessage(Bitmap bitmap) {
        if(bitmap == null) {
            return;
        }

        if(UDEnvConstants.isDebugMode) {
            Log.e(TAG, "sendBitmapMessage:h=" + bitmap.getHeight() + " w=" + bitmap.getWidth());
        }

        scaleBitmap(this, null, bitmap);

    }


    /**
     * 发送一条图片消息
     * @param bitmap
     */
    private void sendBitmapMessage(String photoPath) {
        if(UDEnvConstants.isDebugMode) {
            Log.w(TAG, "sendBitmapMessage : potoPath=" + photoPath);
        }

        scaleBitmap(this, photoPath, null);

    }


    /**
     * 七牛上传进度
     */
    private UpProgressHandler mUpProgressHandler = new UpProgressHandler() {
        public void progress(String key, double percent) {
            if(UDEnvConstants.isDebugMode) {
                Log.w(TAG, "UpCompletion : key=" + key + "  percent=" + percent);
            }
        }
    };


    /**
     * 七牛上传完成
     */
    private UpCompletionHandler mUpCompletionHandler = new UpCompletionHandler() {
        @Override
        public void complete(String key, ResponseInfo info, JSONObject response) {

            if(UDIMActivity.this.isFinishing() || !Thread.currentThread().isAlive()) {
                return;
            }

            // 可以点击其他任何按钮
            llBottom.setVisibility(View.VISIBLE);
            llUpload.setVisibility(View.GONE);

            if(null != response && response.has("key")) {
                if(UDEnvConstants.isDebugMode) {
                    Log.w(TAG, "UpCompletion : key=" + key + "\ninfo=" + info.toString() + "\nresponse=" + response.toString());
                }

                String qiniuKey = response.optString("key");
                String imageUrl = UDEnvConstants.UD_QINIU_UPLOAD_IMAGE + qiniuKey;

                // 显示病保存上传之后的图片消息
                if(currentUploadImageMessage != null) {
                    currentUploadImageMessage.text_url = imageUrl;

                    UDIMDBManager.getInstance().addMessage(currentUploadImageMessage);

                    mChatAdapter.addItem(currentUploadImageMessage);
                    lvConversation.smoothScrollToPosition(mChatAdapter.getCount());

                    if(xmppThread != null) {
                        xmppThread.sendMessage(UDIMMessage.TYPE_IMAGE, imageUrl);
                    }
                }

                currentUploadImageMessage = null;
                return;
            }

            Toast.makeText(UDIMActivity.this, R.string.udesk_upload_image_error, Toast.LENGTH_LONG).show();
        }
    };


    /**
     * 缩放图片
     * path和bitmap不会同时存在
     * @param context
     * @param path    图片存放路径
     * @param bitmap  图片实际内容
     */
    private void scaleBitmap(Context context, String path, Bitmap bitmap) {

        // 不可以在点击其他任何按钮
        llBottom.setVisibility(View.GONE);
        llUpload.setVisibility(View.VISIBLE);
        tvUpload.setText(R.string.udesk_upload_image_process);

        if(!TextUtils.isEmpty(path)) {
            new ScaleBitmapTask(this).execute(path);
        } else {
            new ScaleBitmapTask(this).execute(bitmap);
        }

    }


    /**
     * 缩放图片任务
     * 会把大图片缩放成
     * @author xutao
     *
     */
    private class ScaleBitmapTask extends AsyncTask<Object, Integer, String[]> {

        private int thumbnailMaxWH;

        public ScaleBitmapTask(Context context) {
            thumbnailMaxWH = (int)(context.getResources().getDisplayMetrics().density * 100);
        }

        @Override
        protected String[] doInBackground(Object... params) {
            try {

                Bitmap sourceImage = null, scaleImage = null, thumbnailImage = null;

                if(params[0] instanceof Bitmap) {
                    sourceImage = (Bitmap)params[0];
                } else if(params[0] instanceof String) {
                    sourceImage = BitmapFactory.decodeFile((String)params[0]);
                }
                if(sourceImage == null) {
                    return null;
                }

                int width = sourceImage.getWidth();
                int height = sourceImage.getHeight();
                int max = Math.max(width, height);

                BitmapFactory.Options factoryOptions = new BitmapFactory.Options();
                factoryOptions.inJustDecodeBounds = false;
                factoryOptions.inPurgeable = true;

                // 获取原图数据
                ByteArrayOutputStream stream = new ByteArrayOutputStream();
                sourceImage.compress(Bitmap.CompressFormat.JPEG, 100, stream);
                byte[] data = stream.toByteArray();

                String imageName = UDUtils.MD5(data);

                File scaleImageFile = UDUtils.getOutputMediaFile(imageName + "_upload.jpg");
                if (!scaleImageFile.exists()) {
                    // 缩略图不存在，生成上传图
                    if(max > 1024) {
                        factoryOptions.inSampleSize = max / 1024;
                    } else {
                        factoryOptions.inSampleSize = 1;
                    }

                    FileOutputStream fos = new FileOutputStream(scaleImageFile);
                    scaleImage = BitmapFactory.decodeByteArray(data, 0, data.length, factoryOptions);
                    scaleImage.compress(Bitmap.CompressFormat.JPEG, 80, fos);
                    fos.close();
                    fos = null;

                }

                File thumbnailFile = new File(scaleImageFile.getParent() + File.separator + imageName + "_thumbnail.jpg");
                if(!thumbnailFile.exists()) {

                    factoryOptions.inSampleSize = (int)Math.ceil(max / thumbnailMaxWH);

                    FileOutputStream fos = new FileOutputStream(thumbnailFile);
                    thumbnailImage = BitmapFactory.decodeByteArray(data, 0, data.length, factoryOptions);
                    thumbnailImage.compress(Bitmap.CompressFormat.JPEG, 80, fos);
                    fos.close();
                    fos = null;

                }

                if(thumbnailImage != null) {
                    thumbnailImage.recycle();
                    thumbnailImage = null;
                }
                if(scaleImage != null) {
                    scaleImage.recycle();
                    scaleImage = null;
                }
                if(sourceImage != null) {
                    sourceImage.recycle();
                    sourceImage = null;
                }
                data = null;

                return new String[]{scaleImageFile.getPath(), thumbnailFile.getPath() };

            } catch (Exception e) {
                if (UDEnvConstants.isDebugMode) {
                    Log.e(TAG, e.toString());
                }
                return null;
            }

        }


        @Override
        protected void onPostExecute(String[] path) {

            if(TextUtils.isEmpty(path[0]) || TextUtils.isEmpty(path[1])) {

                if(UDIMActivity.this.isFinishing() || !Thread.currentThread().isAlive()) {
                    return;
                }

                // 可以进行其他操作
                llBottom.setVisibility(View.VISIBLE);
                llUpload.setVisibility(View.GONE);

                Toast.makeText(UDIMActivity.this, R.string.udesk_upload_image_error, Toast.LENGTH_LONG).show();

            } else {

                tvUpload.setText(R.string.udesk_upload_image);

                // 上传原图
                UploadManager uploadManager = new UploadManager();
                uploadManager.put(
                        path[0],
                        null,
                        UDUserManager.getInstance().getQiniuToken(),
                        mUpCompletionHandler,
                        new UploadOptions(null, null, false, mUpProgressHandler, null));

                currentUploadImageMessage = new UDIMMessage();
                currentUploadImageMessage.type = UDIMMessage.TYPE_MINE | UDIMMessage.TYPE_IMAGE;
                currentUploadImageMessage.thumbnailPath = path[1];
            }
        }

    }

}

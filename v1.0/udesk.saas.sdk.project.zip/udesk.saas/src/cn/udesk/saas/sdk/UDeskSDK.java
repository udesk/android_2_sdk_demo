/**
 * 对外的接口
 * 采用单例模式，一般不修改
 *
 * @author xutao
 */

package cn.udesk.saas.sdk;

import android.app.Activity;
import android.content.Intent;
import android.util.Log;
import cn.udesk.saas.sdk.activity.UDIMActivity;
import cn.udesk.saas.sdk.activity.UDHelperActivity;
import cn.udesk.saas.sdk.manager.UDUserManager;
import cn.udesk.saas.sdk.utils.UDEnvConstants;

public class UDeskSDK {

    public final static int MODE_HELPER   = 0x01;
    public final static int MODE_IM       = 0x02;
    public final static int MODE_BOTH     = (MODE_HELPER | MODE_IM);

    private int sdkMode = MODE_BOTH;

    /**
     * 接口是单例形式的
     */
    private static UDeskSDK instance = null;

    private UDeskSDK() {
    }

    public static UDeskSDK getInstance() {
        if(instance == null) {
            instance = new UDeskSDK();
        }
        return instance;
    }

    public void setMode(int mode) {
        sdkMode = mode;
        UDUserManager.getInstance().setSDKMode(mode);
    }

    /**
     * 设置二级域名，必须在登录前调用(必接)
     * @param subDomain
     */
    public void setSubDomain(String subDomain) {
        UDUserManager.getInstance().setSubDomain(subDomain);
    }

    /**
     * 设置密钥，必须在登录前调用(必接)
     * @param secretKey
     */
    public void setSecretKey(String secretKey) {
        UDUserManager.getInstance().setSecretKey(secretKey);
    }

    /**
     * 设置第三方应用的用户ID(选接)
     * @param appUserId 第三方应用的用户ID
     */
    public void setUserInfo(String userId, String nick) {
        UDUserManager.getInstance().setUserInfo(userId, nick);
    }

    /**
     * 打开对应的activity
     * @param activity
     */
    public void open(Activity activity) {

        if(UDEnvConstants.isDebugMode) {
            Log.e("udesksdk", "sdkMode = " +sdkMode);
        }

        Intent intent;
        if((sdkMode & MODE_HELPER) == MODE_HELPER) {
            if(UDEnvConstants.isDebugMode) {
                Log.e("udesksdk", "MODE_HELPER");
            }
            intent = new Intent(activity, UDHelperActivity.class);
        } else {
            intent = new Intent(activity, UDIMActivity.class);
        }
        activity.startActivity(intent);
    }

}

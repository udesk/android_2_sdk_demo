package cn.udesk.saas.demo;


import android.app.Activity;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.EditText;
import cn.udesk.saas.sdk.UDeskSDK;

public class MainActivity extends Activity {

    private final static String UDESK_SUB_DOMAIN = "在udesk平台填写的域名";
    private final static String UDESK_SECRET_KEY = "udesk平台分配的secret key";

    private EditText etSubDomain, etSecret;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // 设置用户信息[可选接口]
//        UDeskSDK.getInstance().setUserInfo("您平台的用户ID", "您平台的用户名");

        etSubDomain = (EditText)findViewById(R.id.et_subdomain);
        etSecret = (EditText)findViewById(R.id.et_secret);

        findViewById(R.id.btn_open_helper).setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View v) {
                // 设置当前模式
                openUdesk(UDeskSDK.MODE_HELPER);
            }
        });

        findViewById(R.id.btn_open_im).setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View v) {
                openUdesk(UDeskSDK.MODE_IM);
            }
        });

        findViewById(R.id.btn_open_all).setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View v) {
                // 打开UDesk
                openUdesk(UDeskSDK.MODE_BOTH);
            }
        });
    }


    private void openUdesk(int mode) {

        String subdomain = etSubDomain.getText().toString();
        if(TextUtils.isEmpty(subdomain)) {
            subdomain = UDESK_SUB_DOMAIN;
        }

        // 设置在UDesk平台的二级域名
        UDeskSDK.getInstance().setSubDomain(subdomain);

        String secret = etSecret.getText().toString();
        if(TextUtils.isEmpty(secret)) {
            secret = UDESK_SECRET_KEY;
        }

        // 设置UDesk平台分配的secret key
        UDeskSDK.getInstance().setSecretKey(secret);

        // 设置当前模式
        UDeskSDK.getInstance().setMode(mode);

        // 打开UDesk
        UDeskSDK.getInstance().open(MainActivity.this);

    }


}

/** Automatically generated file. DO NOT MODIFY */
package cn.udesk.saas.sdk;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}